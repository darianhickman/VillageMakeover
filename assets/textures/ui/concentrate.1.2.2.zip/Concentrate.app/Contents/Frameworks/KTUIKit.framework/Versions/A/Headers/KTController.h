@protocol KTController
- (NSArray*)descendants;
- (void)removeObservations;
- (BOOL)hidden;
@end