var ExampleGraph = IgeSceneGraph.extend({
	classId: 'ExampleGraph',
	
	addGraph: function () {
		
	},
	
	removeGraph: function () {
		
	}
});

if (typeof(module) !== 'undefined' && typeof(module.exports) !== 'undefined') { module.exports = ExampleGraph; }