var ServerNetworkEvents = {
	example: function (data, socket) {}
};

if (typeof(module) !== 'undefined' && typeof(module.exports) !== 'undefined') { module.exports = ServerNetworkEvents; }