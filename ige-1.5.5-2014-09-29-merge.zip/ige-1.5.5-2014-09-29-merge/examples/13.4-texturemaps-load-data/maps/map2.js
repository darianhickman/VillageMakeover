var map2 = {
	data: [[[0,1],[0,1],[0,2]]]
};

if (typeof(module) !== 'undefined' && typeof(module.exports) !== 'undefined') { module.exports = map2; }