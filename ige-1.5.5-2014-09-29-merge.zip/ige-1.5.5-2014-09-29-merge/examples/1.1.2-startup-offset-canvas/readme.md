# Canvas Offset
In this example the canvas that the engine paints to is offset by a couple of divs. In
order to display the engine correctly we manually set the size of the canvas rather
than have the engine automatically resize it.
