# Blank Project
This project is set up to work from outside the ige folder because any project you create should be outside the ige
repository folder. To use this project, copy the "blank_game" folder one level below the ige folder in your filesystem.

For instance, if your ige folder is at C:\Development\ige then copy this folder so it is located at
C:\Development\blank_game

You can then test the project is working by loading C:\Development\blank_game\index.html